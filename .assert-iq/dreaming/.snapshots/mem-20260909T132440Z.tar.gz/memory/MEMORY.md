# MEMORY.md — Project Memory Index

_Last consolidated: never — run `/dream` to populate_

<!--
Long-term memory INDEX for the Assert.IQ Dreaming feature (loaded at session
start, index only). Maintained by the /dream consolidation pass:
  - Hard cap: 200 lines; one-line pointers into topics/.
  - Absolute dates only. Facts/decisions/preferences, not transcript excerpts.
Hand-edit freely; the instruction files under .github/instructions/ are the
immutable rules tier and are never modified by dreaming.
-->

## Architecture

_(no entries yet)_

## Workflow

_(no entries yet)_

## Active Gotchas

_(no entries yet)_

# Architecture

- chumsweatherapp is a small React 16 app (Create React App / `react-scripts` 3.4.1) that
  looks up current weather via the OpenWeatherMap REST API, called directly from the browser
  — no owned backend, no auth, no payment/PII data. Built by Jarius Hayes as a hobby project
  for a family member ("Chum"); solo maintainer, no team. Deployed to Firebase Hosting
  (project `chum-weather`). *(observed 2026-08-28)*
- Test framework is Jest via `react-scripts test` (`yarn test`); tests are colocated with
  source (`src/App.test.js`, `src/components/WeatherCard/*.test.js`), no `tests/` dir.
  *(confirmed 2026-08-28)*
- GitHub repo `sayrilamar/chumsweatherapp`, default branch `master` (not `main`).
  *(confirmed 2026-08-28)*
- The OpenWeatherMap key lives in `.env.local` (gitignored) as
  `REACT_APP_OPENWEATHER_API_KEY`, read via `process.env` in `src/App.js` — the earlier
  hardcoded-key issue is resolved. *(confirmed 2026-09-03)*
- `leaflet` (vanilla, not `react-leaflet`) is a dependency as of 2026-09-03, added for the
  weather-map feature below — chosen specifically because it has no React-version coupling,
  unlike `react-leaflet` which would pin a React major version against this app's React 16.

## Feature set (as of 2026-09-03)

Built out incrementally across several sessions since 2026-08-28, all against OpenWeatherMap's
free tier (see [topics/openweathermap-api.md](openweathermap-api.md) for the endpoint catalog):
weather-reactive gradient theme, city autocomplete + ZIP code search, on-demand geolocation
("Use My Location"), local time/timezone display, 5-day + "later today" forecast strips, a
weather-details panel (wind/humidity/visibility/sunrise/sunset, barometric pressure with a
localStorage-backed 3-hour trend arrow in mb+inHg), air quality index + UV index, full
precipitation exposure (active rain/snow rate in both the hero card and a details tile,
mm+inches; a chance-of-rain badge with daily accumulation on both forecast strips — all hidden
entirely when there's nothing to show), and a live "Weather Map" section (Leaflet +
OpenStreetMap base layer, toggling OpenWeatherMap's precipitation/clouds/wind/temp/pressure
tile overlays, centered on the searched city).

## Assert.IQ pack — tailored config decisions (2026-08-28)

Installed in **trial mode** (`.assert-iq/`, `.github/instructions/`, etc. hidden from git via
`.git/info/exclude`). Key `.assert-iq/config.yaml` choices, made explicitly by the user during
`/assert-iq-tailor`:

- `tracker.type: "none"` — no issue tracker in use; traceability comments are deliberately
  omitted project-wide (see `qi-traceability.instructions.md`'s dormancy note).
- `maturity.tier: "mid"` — an explicit user override. By indicator count alone this project
  would score `early` (no CI existed before tailoring, no regression suite, solo maintainer).
  User chose `mid` anyway to get automated test generation + PR risk assessment active;
  Agentic Healing runs suggest-only as the accepted trade-off. Re-evaluation due 2026-11-26.
- `business_metrics` figures ($25 escape cost, $25/hr burden rate) are nominal placeholders,
  not real costs — user asked to keep `/measure-qi-impact` runnable rather than disable it.
- `.vscode/mcp.json` trimmed to just `github` + `git` servers (everything else commented out,
  not deleted, in a restore block) — see Active Gotchas for a reversion incident.
